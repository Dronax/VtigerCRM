Instructions on use.

This is a workstation patch.

Log out of Premier. Make sure the login box is also exited.
Backup the C:\Program Files (x86)\Gallagher\Command Centre\Client directory (rename a copy).
On every workstation, copy the three provided files into C:\Program Files (x86)\Gallagher\Command Centre\Client, overwriting the existing files.
Start Premier.

There is no reason to stop Command Centre services.

Notes

The Camera tile is truncated by a couple of mm on the left hand edge but that will not affect any functionality or view of the video or controls..
It is no longer possible to employ a functioning URL tile.
