/*****************************************************************************************

	Time and Attendance Query example - 1

	Last Modified: 15 July 2014

*****************************************************************************************

This SQL query example is designed to assist developers to extract data from the Gallagher Command Centre databases for 
Time and Attendance purposes.

1. The query can filter by a particular Access Zone if required.
2. The query filter by a PDF value if required.


The query places the results in a table and then seaches the table to extract the first and last events for each cardholder along with the Time On Site.

Example:

	FirstName	LastName	FirstBadge				LastBadge			TimeOnSite
	---------------------------------------------------------------------------------
	Peter		Wilson 		2014-07-18 11:28:27		2014-07-18 14:55:12		03:27:00  
	Ian			Martin 		2014-07-19 03:30:00		2014-07-19 03:31:08		00:01:00  
	Lea			MacDonald	2014-07-18 23:28:26		2014-07-19 00:20:19		00:52:00                                                   


Once you are familiar with the query, it is a simple matter to modify it for specific requirements.


***********************************************************************************************************

The information contained in this document is intended for readers who are familiar with Database Systems,
SQL, and have access to Microsoft SQL Enterprise Manager or other such products for accessing SQL databases. 

Gallagher Systems cannot provide support in these areas.

This example code is provided by Gallagher for demonstration purposes only. 

It is supplied 'as -is' without warranty, guarantee or support.

Independent vendors should implement their own code to meet individual customer requirements
	
Gallagher or its subsideries assumes no liablity for losses (either directly or indirectly) incurred from direct use of code supplied.	
***********************************************************************************************************/

use CCFTCentral
set nocount on

/* Declare variables to be inserted into the query */
Declare @AccessZone nVarChar(110)	-- The Access Zone monitored for T&A.
Declare @PDFfield nVarChar(50)		-- The Personal Data Field to be used for filtering cardholders.
Declare @PDFvalue nVarChar(50)		-- The Personal Data Field value to be searched for.
Declare @StartDate datetime			-- The start date to search from
Declare @EndDate datetime			-- The end date to search to
Declare @utcOffset int				-- UTC offset from GMT. For example, Singapore is 8.
Declare @EntryID int				-- The FT identifier for an entry event. Default is '20001'.
Declare @ExitID int					-- The FT identifier for an exit event. Default is '20003'.
									-- Note: If one reader is used for IN and OUT, set @ExitID to '20001'.


/* Filters
Note: These will be different for your requirements. */
Set @AccessZone = 'Entry Access Zone'	-- The Access Zone to filter by.
Set @PDFfield = 'Company'				-- The name of the PDF field to filter by.
Set @PDFvalue = 'Gallagher Group'		-- The value in the PDF field to filter by.

Set @utcoffset = datediff(hh, getutcdate(), getdate())	/* Automatically calculates the GMT offset against UTC time */
Set @EntryID = '20001'
Set @ExitID = '20001'				-- Note: If one reader is used for IN and OUT, set @ExitID to '20001'.

-- The following two statements select the time period for the current day
Set @StartDate = convert(nvarchar(100), GetDate(), 110)	-- Get today's date
Set @EndDate = @StartDate + '23:59:00'

-- If you wish to change the date range, enter data for the StartDate and EndDate below and uncomment the lines
-- Set @StartDate = '2014-07-13 00:00:00'
-- Set @EndDate = '2014-07-18 23:59:00'
/***********************************************************************************************************/

declare @AG_id int, @AG_name nchar(1024), @CH_id int, @CH_FirstName nchar(1024), @CH_LastName nchar(1024), @PDF_Value nchar(1024)
declare @EventID int, @EntryTime datetime, @ExitTime datetime


/* Create temp table for cardholders */
IF EXISTS (select * from [tempdb].[dbo].[sysobjects] where id = object_id(N'tempdb..#CHs')) 
DROP TABLE #CHs 
create table #CHs
	(CH_id int, 
	CH_FirstName nchar(1024),
	CH_LastName nchar(1024),
	CH_APDF_String nchar(1024))


/* Create temp table for the final output results */
IF EXISTS (select * from [tempdb].[dbo].[sysobjects] where id = object_id(N'tempdb..#Entry_Exit')) 
DROP TABLE #Entry_Exit 
create table #Entry_Exit
	(FirstName nchar(1024),
	LastName nchar(1024),
	PDF nchar(1024),
	FirstBadge datetime,
	LastBadge datetime,
	TimeOnSite nchar(100))

	/* Get the cardholders */
	delete #CHs	
	insert #CHs
		select cardholder.FTItemID, cardholder.FirstName, cardholder.LastName, PersonalDataString.Value
			from cardholder join PersonalDataString 
				on cardholder.FTItemID = PersonalDataString.cardholderid join Ftitem as pdfFTItem
				on PersonalDataString.personaldatafieldid = pdfFTItem.id and pdfFTItem.name = @PDFfield
		
		/* Use this line to filter by PDF value if required */
		-- where PersonalDataString.value = @PDFvalue
 
		
	/* For each cardholder find the entry and exit events */
	declare CHs_cursor cursor for
		select * from #CHs

	open CHs_cursor
	Fetch next from CHs_Cursor 
	into @CH_id, @CH_FirstName, @CH_LastName, @PDF_Value
		
	WHILE @@FETCH_STATUS = 0
	Begin
		/* Get the last entry event for the current cardholder for a zone of interest */
			select top 1 @eventid = ccftevent.dbo.event.ID, @entrytime = ccftevent.dbo.event.OccurrenceTime 
				from ccftevent.dbo.event join ccftevent.dbo.relateditems as CH_RI
					on ccftevent.dbo.event.id = CH_RI.eventid join ccftevent.dbo.relateditems as AZ_RI
					on ccftevent.dbo.event.id =  AZ_RI.eventid join AccessZone 
					on AZ_RI.FTItemID = AccessZone.FTItemId join FTItem 
					on FTItem.ID = AccessZone.FTItemId
	 
			/* Use this to filter by Access Zone */
			-- where CH_RI.FTItemId = @CH_id and  EventType = @EntryID /*the entry event*/ and Ftitem.name = @AccessZone and

			/* or use this where no Access Zone filter is required */
			where CH_RI.FTItemId = @CH_id and EventType = @EntryID /*the entry event*/ and


			-- Date range
			DateAdd(HH,@utcoffset,CCFTEvent..Event.OccurrenceTime) BETWEEN @StartDate and @EndDate

							
			order by ccftevent.dbo.event.occurrencetime asc

/* Get the last exit event */
		set @ExitTime = 
			(select top 1 ccftevent.dbo.event.OccurrenceTime 
			
				from ccftevent.dbo.event join ccftevent.dbo.relateditems as CH_RI
					on ccftevent.dbo.event.id = CH_RI.eventid join ccftevent.dbo.relateditems as AZ_RI
					on ccftevent.dbo.event.id =  AZ_RI.eventid join AccessZone 
					on AZ_RI.FTItemID = AccessZone.FTItemId join FTItem 
					on FTItem.ID = AccessZone.FTItemId 
	 
			/* Use this to filter by Access Zone */
			-- where CH_RI.FTItemId = @CH_id and  EventType = @EntryID /*the entry event*/ and Ftitem.name = @AccessZone and

			/* Or use this where no Access Zone filter is required */
			where CH_RI.FTItemId = @CH_id and  EventType = @EntryID /*the entry event*/ and
							
				-- Date range
				DateAdd(HH,@utcoffset,CCFTEvent..Event.OccurrenceTime) BETWEEN @StartDate and @EndDate

			order by ccftevent.dbo.event.occurrencetime desc)

	insert into #Entry_Exit
			values(@CH_FirstName, @CH_LastName, @PDF_Value, DateAdd(hour, @utcOffset, @EntryTime), DateAdd(hour, @utcOffset, @ExitTime), convert(nchar(100), dateadd(n, datediff(n, @EntryTime, @ExitTime), '2000-01-01'), 8))
		Fetch next from CHs_Cursor
		into @CH_id, @CH_FirstName, @CH_LastName, @PDF_Value		
	End
	
	close CHs_Cursor
	deallocate CHs_Cursor


/* Present the final result set */
-- Alternative date formats can be found at; http://www.sql-server-helper.com/tips/date-formats.aspx

Select FirstName, LastName,

		-- If no data is available, SQL returns NULL. The NULL value can be changed as required. 
		IsNull(CONVERT(VARCHAR(19), DateAdd(HH,@utcoffset,FirstBadge) , 120),'00:00') as 'IN Time', -- YYYY-MM-DD HH-MM-SS
		IsNull(CONVERT(VARCHAR(19), DateAdd(HH,@utcoffset,LastBadge) , 120), '00:00') as 'OUT Time', -- YYYY-MM-DD HH-MM-SS
		IsNull(TimeOnSite, '00:00') as 'Total Hours'

FROM #Entry_Exit

	-- Only display events which have a Time on Site.
	Where TimeOnSite <> '00:00'
